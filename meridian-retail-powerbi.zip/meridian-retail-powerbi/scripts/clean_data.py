"""Clean Meridian Retail CSV files per case study Phase 3 requirements."""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
CLEAN = ROOT / "data" / "cleaned"
LOG = ROOT / "docs" / "data-quality-log.md"

OFFICIAL_PAYMENT_METHODS = {
    "credit card",
    "debit card",
    "cash",
    "upi",
    "net banking",
}


def title_case_words(value: str) -> str:
    return " ".join(part.capitalize() for part in value.split())


def clean_text(series: pd.Series) -> pd.Series:
    return (
        series.fillna("")
        .astype(str)
        .str.replace("\u00a0", " ", regex=False)
        .str.strip()
        .str.replace(r"\s+", " ", regex=True)
    )


def standardize_segment(value: str) -> str:
    normalized = value.strip().lower()
    mapping = {
        "consumer": "Consumer",
        "small business": "Small Business",
        "corporate": "Corporate",
    }
    return mapping.get(normalized, value)


def standardize_payment_method(value: str) -> str:
    normalized = (
        value.strip()
        .lower()
        .replace("_", " ")
        .replace("-", " ")
    )
    normalized = re.sub(r"\s+", " ", normalized)
    mapping = {
        "credit card": "Credit Card",
        "debit card": "Debit Card",
        "cash": "Cash",
        "upi": "UPI",
        "net banking": "Net Banking",
    }
    if normalized in mapping:
        return mapping[normalized]
    if normalized in OFFICIAL_PAYMENT_METHODS:
        return mapping[normalized]
    return "Other"


def standardize_channel(value: str) -> str:
    normalized = value.strip().lower()
    if normalized == "online":
        return "Online"
    if normalized == "store":
        return "Store"
    return value


def standardize_status(value: str) -> str:
    normalized = value.strip().lower()
    mapping = {
        "completed": "Completed",
        "cancelled": "Cancelled",
        "returned": "Returned",
        "pending": "Pending",
    }
    return mapping.get(normalized, value)


def parse_order_date(value: str) -> pd.Timestamp | pd.NaT:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return pd.NaT
    text = str(value).strip()
    if not text:
        return pd.NaT

    # ISO: YYYY-MM-DD
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return pd.to_datetime(text, format="%Y-%m-%d", errors="coerce")

    # DD-Mon-YYYY (e.g. 04-Jun-2024)
    if re.fullmatch(r"\d{2}-[A-Za-z]{3}-\d{4}", text):
        return pd.to_datetime(text, format="%d-%b-%Y", errors="coerce")

    # Slash formats: disambiguate by first group
    if "/" in text:
        parts = text.split("/")
        if len(parts) == 3:
            first, second, year = parts
            if len(year) == 2:
                year = f"20{year}"
            # Month/day when first group <= 12 and second > 12
            if int(first) <= 12 and int(second) > 12:
                return pd.to_datetime(
                    f"{second}/{first}/{year}", format="%d/%m/%Y", errors="coerce"
                )
            # Day/month when first group > 12
            if int(first) > 12:
                return pd.to_datetime(text, format="%d/%m/%Y", errors="coerce")
            # Ambiguous: treat as MM/DD/YYYY per instructor guidance for US-style rows
            return pd.to_datetime(text, format="%m/%d/%Y", errors="coerce")

    return pd.to_datetime(text, errors="coerce")


def clean_dim_product(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in ["Category", "Subcategory", "Brand", "Supplier", "ProductName"]:
        out[col] = clean_text(out[col])
    out["Category"] = out["Category"].apply(
        lambda x: title_case_words(x) if x else "Unknown"
    )
    out["Subcategory"] = out["Subcategory"].apply(
        lambda x: title_case_words(x) if x else "Unknown"
    )
    out["Brand"] = out["Brand"].replace("", "Unknown")
    out["Supplier"] = out["Supplier"].replace("", "Unknown")
    out["ProductLaunchDate"] = pd.to_datetime(out["ProductLaunchDate"], errors="coerce")
    out["StandardCost"] = pd.to_numeric(out["StandardCost"], errors="coerce")
    out["ListPrice"] = pd.to_numeric(out["ListPrice"], errors="coerce")
    return out


def clean_dim_customer(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["CustomerName"] = clean_text(out["CustomerName"]).apply(title_case_words)
    out["City"] = clean_text(out["City"]).replace("", "Unknown")
    out["CustomerSegment"] = clean_text(out["CustomerSegment"]).apply(standardize_segment)
    out["SignupDate"] = pd.to_datetime(out["SignupDate"], errors="coerce")
    if "RegionName_Raw" in out.columns:
        out = out.drop(columns=["RegionName_Raw"])
    return out


def clean_dim_store(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["StoreName"] = clean_text(out["StoreName"]).apply(title_case_words)
    out["StoreManager"] = clean_text(out["StoreManager"]).replace("", "Unassigned")
    out["StoreOpeningDate"] = pd.to_datetime(out["StoreOpeningDate"], errors="coerce")
    return out


def clean_fact_sales(df: pd.DataFrame, valid_products: set[str]) -> tuple[pd.DataFrame, dict]:
    out = df.copy()
    stats: dict[str, int | list[str]] = {}

    raw_count = len(out)
    stats["raw_row_count"] = raw_count

    out = out.drop_duplicates()
    stats["duplicate_rows_removed"] = raw_count - len(out)

    out["OrderDate"] = out["OrderDate"].apply(parse_order_date)
    out["ShipDate"] = pd.to_datetime(out["ShipDate"], errors="coerce")
    out["DiscountPercent"] = pd.to_numeric(out["DiscountPercent"], errors="coerce").fillna(0)
    out["Quantity"] = pd.to_numeric(out["Quantity"], errors="coerce")
    out["UnitPrice"] = pd.to_numeric(out["UnitPrice"], errors="coerce")
    out["CostAmount"] = pd.to_numeric(out["CostAmount"], errors="coerce")

    out["PaymentMethod"] = clean_text(out["PaymentMethod"]).apply(standardize_payment_method)
    out["SalesChannel"] = clean_text(out["SalesChannel"]).apply(standardize_channel)
    out["OrderStatus"] = clean_text(out["OrderStatus"]).apply(standardize_status)

    orphan_mask = ~out["ProductID"].isin(valid_products)
    stats["orphan_product_rows"] = int(orphan_mask.sum())
    stats["orphan_product_order_ids"] = out.loc[orphan_mask, "OrderID"].tolist()
    out = out.loc[~orphan_mask].copy()

    stats["blank_customer_id_rows"] = int(out["CustomerID"].isna().sum() + (out["CustomerID"] == "").sum())
    stats["blank_order_date_rows"] = int(out["OrderDate"].isna().sum())
    stats["cleaned_row_count"] = len(out)

    return out, stats


def build_dim_date(min_date: pd.Timestamp, max_date: pd.Timestamp) -> pd.DataFrame:
    dates = pd.date_range(min_date.normalize(), max_date.normalize(), freq="D")
    df = pd.DataFrame({"Date": dates})
    df["Year"] = df["Date"].dt.year
    df["MonthNumber"] = df["Date"].dt.month
    df["MonthName"] = df["Date"].dt.strftime("%B")
    df["Quarter"] = "Q" + df["Date"].dt.quarter.astype(str)
    df["YearMonth"] = df["Date"].dt.strftime("%Y-%m")
    df["Day"] = df["Date"].dt.day
    df["DayName"] = df["Date"].dt.day_name()
    df["WeekNumber"] = df["Date"].dt.isocalendar().week.astype(int)
    return df


def compute_validation_metrics(fact_sales: pd.DataFrame, fact_targets: pd.DataFrame) -> dict:
    shipped = fact_sales[fact_sales["OrderStatus"].isin(["Completed", "Returned"])].copy()
    shipped["GrossSales"] = shipped["Quantity"] * shipped["UnitPrice"]
    shipped["DiscountAmount"] = (
        shipped["GrossSales"] * shipped["DiscountPercent"] / 100
    )
    shipped["NetSales"] = shipped["GrossSales"] - shipped["DiscountAmount"]
    shipped["TotalCost"] = shipped["CostAmount"] * shipped["Quantity"].apply(
        lambda q: 1 if q >= 0 else -1
    )

    completed = fact_sales[fact_sales["OrderStatus"] == "Completed"]
    returned = fact_sales[fact_sales["OrderStatus"] == "Returned"]

    net_sales = shipped["NetSales"].sum()
    total_profit = shipped["NetSales"].sum() - shipped["TotalCost"].sum()

    return {
        "gross_sales": round(shipped["GrossSales"].sum(), 2),
        "discount_amount": round(shipped["DiscountAmount"].sum(), 2),
        "net_sales": round(net_sales, 2),
        "total_cost": round(shipped["TotalCost"].sum(), 2),
        "total_profit": round(total_profit, 2),
        "profit_margin_pct": round((total_profit / net_sales) * 100, 2) if net_sales else 0,
        "total_orders_completed": completed["OrderID"].nunique(),
        "returned_orders": returned["OrderID"].nunique(),
        "return_rate_pct": round(
            returned["OrderID"].nunique()
            / shipped["OrderID"].nunique()
            * 100,
            2,
        ),
        "distinct_customers": completed["CustomerID"].nunique(),
        "total_sales_target": round(fact_targets["SalesTarget"].sum(), 2),
        "target_achievement_pct": round(
            (net_sales / fact_targets["SalesTarget"].sum()) * 100, 1
        ),
        "order_status_counts": fact_sales["OrderStatus"].value_counts().to_dict(),
    }


def write_quality_log(stats: dict, metrics: dict) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    content = f"""# Data Quality Log — Meridian Retail Power BI Project

Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}

## FactSales Cleaning Decisions

| Issue | Decision | Count / Notes |
|-------|----------|---------------|
| Raw row count | Baseline before cleaning | {stats['raw_row_count']} |
| Exact duplicate rows | Removed with `drop_duplicates()` | {stats['duplicate_rows_removed']} removed |
| Orphan ProductID rows | Excluded from model; logged for review | {stats['orphan_product_rows']} rows |
| Blank CustomerID | Kept in fact table; excluded from customer-count measures via DISTINCTCOUNT | {stats['blank_customer_id_rows']} rows |
| Blank OrderDate | Kept as null; excluded from time-based visuals via Date relationship | {stats['blank_order_date_rows']} rows |
| Blank DiscountPercent | Replaced with 0 | Applied to all blanks |
| Negative Quantity | Kept sign as-is for returns | Matches Returned status |
| PaymentMethod variants | Standardized to 5 official methods + Other | COD/Wallet/EMI/Cheque → Other |
| SalesChannel / OrderStatus | Trimmed and title-cased | Online/Store; Completed/Cancelled/Returned/Pending |

### Orphan Product Order IDs
{chr(10).join(f'- {oid}' for oid in stats.get('orphan_product_order_ids', [])) or '- None'}

## DimProduct Cleaning Decisions

- Trimmed and standardized Category/Subcategory to Title Case.
- Blank Category replaced with `Unknown`.
- Blank Brand/Supplier replaced with `Unknown`.

## DimCustomer Cleaning Decisions

- CustomerName trimmed and title-cased.
- CustomerSegment standardized to Consumer / Small Business / Corporate.
- Blank City replaced with `Unknown`.
- `RegionName_Raw` removed (redundant with DimRegion relationship).

## DimStore Cleaning Decisions

- StoreName trimmed and title-cased.
- Blank StoreManager replaced with `Unassigned`.

## Post-Cleaning Row Count

- FactSales cleaned rows: **{stats['cleaned_row_count']}**
- Expected per answer key: **7,370**

## Quick Validation Snapshot

```json
{json.dumps(metrics, indent=2)}
```
"""
    LOG.write_text(content, encoding="utf-8")


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    CLEAN.mkdir(parents=True, exist_ok=True)

    uploads = Path("/agent/uploads")
    file_map = {
        "DimCustomer": "DimCustomer_42d1.csv",
        "DimDate": "DimDate_47aa.csv",
        "DimProduct": "DimProduct_80f0.csv",
        "DimRegion": "DimRegion_ba07.csv",
        "DimSalesperson": "DimSalesperson_0d2d.csv",
        "DimStore": "DimStore_cc16.csv",
        "FactSales": "FactSales_b8df.csv",
        "FactTargets": "FactTargets_83c1.csv",
    }

    for name, filename in file_map.items():
        src = uploads / filename
        dst = RAW / f"{name}.csv"
        dst.write_bytes(src.read_bytes())

    dim_product = clean_dim_product(pd.read_csv(RAW / "DimProduct.csv"))
    dim_customer = clean_dim_customer(pd.read_csv(RAW / "DimCustomer.csv"))
    dim_store = clean_dim_store(pd.read_csv(RAW / "DimStore.csv"))
    dim_region = pd.read_csv(RAW / "DimRegion.csv")
    dim_salesperson = pd.read_csv(RAW / "DimSalesperson.csv")
    fact_targets = pd.read_csv(RAW / "FactTargets.csv")

    valid_products = set(dim_product["ProductID"])
    fact_sales, stats = clean_fact_sales(pd.read_csv(RAW / "FactSales.csv"), valid_products)

    min_date = fact_sales["OrderDate"].min()
    max_date = fact_sales["OrderDate"].max()
    dim_date = build_dim_date(min_date, max_date)

    dim_product.to_csv(CLEAN / "DimProduct.csv", index=False)
    dim_customer.to_csv(CLEAN / "DimCustomer.csv", index=False)
    dim_store.to_csv(CLEAN / "DimStore.csv", index=False)
    dim_region.to_csv(CLEAN / "DimRegion.csv", index=False)
    dim_salesperson.to_csv(CLEAN / "DimSalesperson.csv", index=False)
    fact_sales.to_csv(CLEAN / "FactSales.csv", index=False)
    fact_targets.to_csv(CLEAN / "FactTargets.csv", index=False)
    dim_date.to_csv(CLEAN / "DimDate.csv", index=False)

    metrics = compute_validation_metrics(fact_sales, fact_targets)
    (ROOT / "docs" / "validation-metrics.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8"
    )
    write_quality_log(stats, metrics)

    print(json.dumps({"stats": stats, "metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
