# Meridian Retail Group — Power BI Project

End-to-end Power BI solution for the **Meridian Retail Sales & Business Performance Analysis** case study.

## What's in this project

| Folder / File | Purpose |
|---------------|---------|
| `data/raw/` | Original 8 CSV files from the assignment |
| `data/cleaned/` | Pre-cleaned CSVs (optional fast path) |
| `power-query/` | Power Query M scripts for raw-data import |
| `dax/measures.dax` | All required DAX measures |
| `docs/data-quality-log.md` | Phase 3 deliverable |
| `docs/validation-log.md` | Phase 9 deliverable |
| `docs/business-insights.md` | Phase 10 deliverable |
| `docs/dashboard-spec.md` | Page-by-page visual layout guide |
| `docs/model-relationships.md` | Star schema relationship map |

## Quick start (Power BI Desktop)

### Option A — Fast path (pre-cleaned data)

Best if you want to focus on modeling, DAX, and dashboards.

1. Copy this folder to your machine, e.g. `C:\MeridianRetail\`
2. Open **Power BI Desktop**
3. **Get Data → Text/CSV** and import all 8 files from `data/cleaned/`
4. Follow **Phase 4–7** below (model, measures, reports)

### Option B — Learning path (clean in Power Query)

Best if you're working through the full assignment.

1. Copy `data/raw/` to `C:\MeridianRetail\data\raw\`
2. Import raw CSVs into Power BI
3. Open **Advanced Editor** on each query and paste the matching `.pq` file from `power-query/`
4. Update file paths in the M scripts if your folder differs from `C:\MeridianRetail\`

> **Load order:** Import and clean `DimProduct`, `DimCustomer`, and `DimStore` before `FactSales` (FactSales references DimProduct).

---

## Phase 4 — Data model (star schema)

Create these relationships in **Model view** (all **one-to-many**, **single** filter direction):

| From (1) | To (*) |
|----------|--------|
| `DimDate[Date]` | `FactSales[OrderDate]` |
| `DimProduct[ProductID]` | `FactSales[ProductID]` |
| `DimCustomer[CustomerID]` | `FactSales[CustomerID]` |
| `DimStore[StoreID]` | `FactSales[StoreID]` |
| `DimRegion[RegionID]` | `FactSales[RegionID]` |
| `DimSalesperson[SalespersonID]` | `FactSales[SalespersonID]` |
| `DimDate[YearMonth]` | `FactTargets[TargetMonth]` |
| `DimStore[StoreID]` | `FactTargets[StoreID]` |
| `DimRegion[RegionID]` | `FactTargets[RegionID]` |

**Do not** relate `FactSales` directly to `FactTargets`.

### Date table setup

1. Use the `DimDate` query (built in Power Query or DAX)
2. Right-click `DimDate` → **Mark as date table** → select `Date`
3. Sort `MonthName` by `MonthNumber`
4. Sort `YearMonth` chronologically (natural `YYYY-MM` sort works)

---

## Phase 6 — DAX measures

1. In Power BI, create a new table: **Modeling → New table** → name it `_Metrics`
2. Open `dax/measures.dax` and create each measure (Home → Enter data, or paste via Tabular Editor)
3. Hide `_Metrics` from report view if desired

Key business rules baked into the measures:

- **Net Sales / Profit** include `Completed` + `Returned` orders (returns reduce totals via negative quantity)
- **Cancelled** and **Pending** are excluded from revenue measures
- **Total Cost** uses `CostAmount * SIGN(Quantity)` so returns reverse cost correctly
- All ratios use `DIVIDE()` for safe division

---

## Phase 7 — Dashboard pages

Build 4 report pages per `docs/dashboard-spec.md`:

1. **Executive Dashboard** — CEO / Sales Manager KPIs
2. **Sales Analysis** — channel, category, payment trends
3. **Product & Customer Analysis** — top/bottom products, segments
4. **Regional / Store Performance** — store matrix, targets, returns

---

## Phase 8 — Interactivity checklist

- [ ] Slicers: Year, Region, Channel, Category, Store Type, Year-Month
- [ ] Drill-through: Product Detail page + Store Detail page
- [ ] Tooltip page: Sales, Profit, Margin, YoY Growth, Target Achievement
- [ ] Bookmark: toggle Sales View vs Profit View on a trend chart
- [ ] Conditional formatting: low margins, below-target stores, negative YoY

---

## Validation targets

After building, compare your grand totals to `docs/validation-log.md`. Expected ballpark values:

| Measure | Expected |
|---------|----------|
| Net Sales | ₹19.34 Cr |
| Total Profit | ₹4.25 Cr |
| Profit Margin % | ~22% |
| Total Orders (Completed) | 6,158–6,171 |
| Distinct Customers | 742 |
| Return Rate % | ~7.7% |
| Target Achievement % | ~81% |

---

## Final deliverables checklist

- [ ] `.pbix` file with cleaned model + 4 report pages
- [ ] Screenshot of Model view (star schema)
- [ ] List of DAX measures (`dax/measures.dax`)
- [ ] Data quality log (`docs/data-quality-log.md`)
- [ ] Validation log (`docs/validation-log.md`)
- [ ] Business insights (`docs/business-insights.md`)
