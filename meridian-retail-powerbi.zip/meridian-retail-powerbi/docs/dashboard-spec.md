# Dashboard Specification — 4 Report Pages

## Global design standards

- **Color palette:** Dark navy header (#1B2A4A), accent teal (#00A8A8), neutral gray backgrounds
- **Font:** Segoe UI, 10–12pt body, 14–18pt titles
- **Layout:** KPI cards top row → slicer panel left (200px) → main visuals right
- **Consistent slicer position** on every page (left column)

---

## Page 1 — Executive Dashboard

**Audience:** CEO, Sales Manager

### KPI Cards (top row)
| Visual | Measure |
|--------|---------|
| Total Sales | `[Net Sales]` |
| Total Profit | `[Total Profit]` |
| Profit Margin % | `[Profit Margin %]` |
| Total Orders | `[Total Orders]` |
| Distinct Customers | `[Distinct Customers]` |

### Charts
| Visual | Fields |
|--------|--------|
| Gauge or bar | `[Net Sales]` vs `[Total Sales Target]` |
| Line chart | `DimDate[MonthName]` × `[Net Sales]` |
| Bar chart | `DimRegion[RegionName]` × `[Net Sales]` |
| Donut | `DimProduct[Category]` × `[Net Sales]` |
| Bar (Top N=5) | `DimProduct[ProductName]` × `[Net Sales]` |

### Slicers
- `DimDate[Year]`
- `DimRegion[RegionName]`
- `FactSales[SalesChannel]`

---

## Page 2 — Sales Analysis

**Audience:** Sales Manager, Finance Manager

| Visual | Fields |
|--------|--------|
| Line | `DimDate[MonthName]` × `[Net Sales]` |
| Column | `DimProduct[Category]` × `[Net Sales]` |
| Bar | `DimProduct[Subcategory]` × `[Net Sales]` |
| Donut | `FactSales[SalesChannel]` × `[Net Sales]` |
| Bar | `FactSales[PaymentMethod]` × `[Net Sales]` |
| Matrix | Rows: `DimRegion[RegionName]`, Values: `[Net Sales]`, `[Total Profit]` |
| Line (2 series) | `DimDate[MonthName]` × `[Net Sales]` + `[Sales Previous Year]` |

### Slicers
- `DimDate[Year]`
- `DimProduct[Category]`
- `DimRegion[RegionName]`

---

## Page 3 — Product & Customer Analysis

**Audience:** Sales Manager, Finance Manager

| Visual | Fields |
|--------|--------|
| Bar (Top 10) | `DimProduct[ProductName]` × `[Net Sales]` |
| Bar (Bottom 10) | `DimProduct[ProductName]` × `[Net Sales]` (sort ascending) |
| Scatter | X: `[Net Sales]`, Y: `[Profit Margin %]`, Details: `ProductName` |
| Donut | `DimCustomer[CustomerSegment]` × `[Net Sales]` |
| Table (Top 10) | `CustomerName`, `[Net Sales]`, `[Total Orders]` |
| Card | `[Average Order Value]` |
| Bar (Pareto) | `DimCustomer[CustomerName]` × `[Net Sales]` cumulative |

### Slicers
- `DimProduct[Category]`
- `DimCustomer[CustomerSegment]`
- `DimDate[Year]`

### Drill-through page: Product Detail
- Fields: `DimProduct[ProductName]`
- Show: product info, sales, profit, margin, quantity, monthly trend, top customers, store breakdown

---

## Page 4 — Regional / Store Performance

**Audience:** Regional Manager, Store Manager, CEO

| Visual | Fields |
|--------|--------|
| Matrix | Rows: `DimStore[StoreName]`, Values: `[Net Sales]`, `[Total Profit]`, `[Target Achievement %]` |
| Bar / Map | `DimRegion[RegionName]` × `[Net Sales]` |
| Clustered bar | `DimStore[StoreName]` × `[Net Sales]` + `[Total Sales Target]` |
| Bar | `DimStore[StoreName]` × `[Profit Margin %]` |
| Bar | `DimStore[StoreName]` × `[Total Orders]` |
| Bar | `DimStore[StoreName]` × `[Return Rate %]` |
| Table (ranked) | Store, Net Sales, Profit, Target %, conditional formatting |

### Slicers
- `DimRegion[RegionName]`
- `DimStore[StoreType]`
- `DimDate[YearMonth]`

### Drill-through page: Store Detail
- Fields: `DimStore[StoreName]`
- Show: store info, sales vs target, profit, margin, monthly trend, top products, salesperson performance

---

## Interactivity (Phase 8)

### Tooltip page
- Enable: Page information → "Allow use as tooltip"
- Show on hover: Region or Product
- Fields: `[Net Sales]`, `[Total Profit]`, `[Profit Margin %]`, `[Sales YoY Growth %]`, `[Target Achievement %]`

### Bookmark example
- **Sales View:** line chart shows `[Net Sales]` and `[Sales YTD]`
- **Profit View:** same chart shows `[Total Profit]` and `[Profit YTD]`
- Two buttons toggle between bookmarks

### Conditional formatting rules
| Visual | Rule |
|--------|------|
| Product margin table | Red if `[Profit Margin %]` < 15% |
| Store matrix Target % | Red if `[Target Achievement %]` < 80% |
| Region bar YoY | Red if `[Sales YoY Growth %]` < 0% |
