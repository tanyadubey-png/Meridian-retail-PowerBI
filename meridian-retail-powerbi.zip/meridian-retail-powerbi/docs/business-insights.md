# Business Insights — Meridian Retail (Phase 10)

## Five Key Findings

1. **Electronics dominates revenue** at ~42% of net sales (₹8.17 Cr), driven by premium products like Photon Notebook Pro and Photon Headphones 200.
2. **Central region leads** with ₹4.51 Cr in net sales, ahead of West (₹4.00 Cr); East trails at ₹3.32 Cr — a ~26% gap between top and bottom region.
3. **Store channel outperforms Online** — ₹11.15 Cr vs ₹8.19 Cr — despite continued online investment.
4. **YoY growth is modest** at +3.16% (2024 vs 2023), below what a fast-scaling retailer would typically target.
5. **Profit margin is healthy at ~22%**, but the business achieves only ~81% of both sales and profit targets across the 24-month period.

## Three Business Problems

1. **Revenue concentration risk** — Top 2 Electronics products account for more revenue than the bottom 3 categories combined; supply or demand shocks would hit hard.
2. **Returns drag profitability** — 7.7% return rate reduces realized revenue; returns reversed ~₹1.28 Cr in discounts alone.
3. **Online underperformance** — Store channel leads by ₹2.96 Cr; if foot traffic slows, there is no strong second channel yet.

## Three Recommendations

1. **Category strategy for Fashion & Office Supplies** — High transaction volume but low revenue share; test bundling and upsell to improve average order value.
2. **Regional best-practice replication** — Study Central and West store formats, assortment, and local marketing; pilot in East region.
3. **Return root-cause analysis** — Prioritize products/categories with highest return rates before further inventory investment.

## Three Opportunities

1. **Online growth** — Identify categories that perform relatively better online and tailor channel-specific merchandising.
2. **Target gap closure** — At 81% achievement, targeted improvement in weakest stores could close much of the remaining 19% gap without raising targets.
3. **Hero product strategy** — Formalize merchandising and inventory priority for top 5 products that drive disproportionate revenue.

## Two Areas Requiring Further Investigation

1. **Fashion's low revenue despite high volume** — Is this deliberate low-price/high-volume strategy or an unrealized trade-up opportunity? Needs category team input.
2. **Breadth of YoY growth** — Is +3.16% broad-based or driven by 1–2 regions/categories? Drill-through analysis recommended before presenting to the board.

## Answers to Key Business Questions

| Question | Answer |
|----------|--------|
| Total revenue (Net Sales) | ₹19.39 Cr |
| Total profit | ₹4.31 Cr |
| Profit margin | 22.2% |
| Top region by sales | Central (₹4.51 Cr) |
| Top category | Electronics (42.3%) |
| Top product by sales | Photon Notebook Pro |
| Top product by profit | Photon Notebook Pro |
| YoY growth (2024 vs 2023) | +3.16% |
| Better channel | Store (57.6% vs 42.4%) |
| Meeting sales target? | No — 81.6% achievement |
| Return rate | 7.73% |
| Most valuable segment | Consumer (largest share) |
