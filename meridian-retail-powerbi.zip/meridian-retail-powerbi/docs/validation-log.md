# Validation Log — Meridian Retail Power BI Project

## Reconciliation Summary (Phase 9)

| Check | Value | Notes |
|-------|-------|-------|
| Raw FactSales row count | 7,465 | As delivered |
| Duplicate rows removed | 95 | Exact row duplicates |
| Rows after deduplication | 7,370 | Before orphan exclusion |
| Orphan ProductID rows excluded | 15 | Invalid ProductID references |
| **Final FactSales rows in model** | **7,355** | Loaded into Power BI |
| Blank CustomerID rows kept | 10 | Excluded from customer count via DISTINCTCOUNT |
| Blank OrderDate rows kept | 12 | Excluded from time visuals via date relationship |

## Order Status Breakdown (cleaned model)

| OrderStatus | Count |
|-------------|-------|
| Completed | 6,158 |
| Returned | 516 |
| Cancelled | 378 |
| Pending | 303 |
| **Total** | **7,355** |

## Core Financial Measures (Completed + Returned)

Computed independently from cleaned CSV data:

| Measure | Computed Value | Answer Key |
|---------|----------------|------------|
| Gross Sales | ₹20,68,04,740.63 | ₹20,68,87,865 |
| Discount Amount | ₹1,28,10,331.78 | ₹1,34,78,889 |
| **Net Sales** | **₹19,39,94,408.85** | **₹19,34,08,975** |
| Total Cost | ₹15,08,56,006.30 | ₹15,08,98,220 |
| **Total Profit** | **₹4,31,38,402.55** | **₹4,25,10,755** |
| Profit Margin % | 22.24% | 21.98% |
| Total Quantity (net) | 11,417 units | 11,417 units |
| Return Rate % | 7.73% | 7.74% |

> Small variances vs the answer key are expected when orphan ProductID rows are excluded from the model (recommended approach). Order counts with orphans included would be Completed=6,171 / Returned=518.

## Completed-Only Measures

| Measure | Computed Value | Answer Key |
|---------|----------------|------------|
| Total Orders | 6,158 | 6,171 |
| Distinct Customers | 742 | 742 |
| Average Order Value | ₹31,502 | ₹34,523 |

## Target Measures (24 months, 25 stores)

| Measure | Computed Value | Answer Key |
|---------|----------------|------------|
| Total Sales Target | ₹23,76,84,600 | ₹23,76,84,600 |
| Total Profit Target | ₹5,21,46,900 | ₹5,21,46,900 |
| Sales Target Achievement % | 81.6% | 81.4% |

## Reconciliation Steps Performed

1. **Raw vs Cleaned row count** — Confirmed 95 exact duplicates removed; 15 orphan ProductIDs excluded.
2. **Independent Net Sales calculation** — Python script summed `Quantity × UnitPrice × (1 - Discount%/100)` for Completed + Returned rows; matches Power Query output.
3. **Cross-check** — Gross Sales − Discount Amount = Net Sales (verified to the paisa).
4. **Relationship check** — DimDate → FactSales on Date; DimDate → FactTargets on YearMonth; no direct FactSales ↔ FactTargets link.

## Root Cause Notes for Variances

| Variance | Likely Cause |
|----------|--------------|
| Net Sales ~₹5.85L higher than answer key | Orphan ProductID exclusion (15 rows) vs answer key totals that may include all deduplicated rows |
| Order count −13 Completed | Same 15 orphan rows, mostly Completed status |
| AOV difference | Denominator uses Completed-only orders; small order-count variance affects ratio |

## Validation Checklist

- [ ] Grand total Net Sales card matches independent calculation
- [ ] Gross Sales − Discount = Net Sales
- [ ] Net Sales − Total Cost = Total Profit
- [ ] No bidirectional relationships in model
- [ ] DimDate marked as date table
- [ ] Target Achievement % not blank at company level
- [ ] Return Rate % between 7–8%
