# Data Model — Star Schema

```
                    DimDate
                   /   |   \
                  /    |    \
           FactSales  |   FactTargets
          /  |  |  \  |   /    \
         /   |  |   \ |  /      \
  DimProduct  |  |  DimStore  DimRegion
              |  |
         DimCustomer  DimSalesperson
```

## Table Roles

| Table | Type | Grain | Rows |
|-------|------|-------|------|
| FactSales | Fact | One row per order line item | 7,355 |
| FactTargets | Fact | One row per store per month | 600 |
| DimDate | Dimension | One row per calendar day | 731 |
| DimProduct | Dimension | One row per product | 60 |
| DimCustomer | Dimension | One row per customer | 800 |
| DimStore | Dimension | One row per store | 25 |
| DimRegion | Dimension | One row per region | 5 |
| DimSalesperson | Dimension | One row per salesperson | 50 |

## Relationships

| # | From | To | Cardinality | Cross-filter |
|---|------|----|-------------|--------------|
| 1 | DimDate[Date] | FactSales[OrderDate] | 1:* | Single |
| 2 | DimProduct[ProductID] | FactSales[ProductID] | 1:* | Single |
| 3 | DimCustomer[CustomerID] | FactSales[CustomerID] | 1:* | Single |
| 4 | DimStore[StoreID] | FactSales[StoreID] | 1:* | Single |
| 5 | DimRegion[RegionID] | FactSales[RegionID] | 1:* | Single |
| 6 | DimSalesperson[SalespersonID] | FactSales[SalespersonID] | 1:* | Single |
| 7 | DimDate[YearMonth] | FactTargets[TargetMonth] | 1:* | Single |
| 8 | DimStore[StoreID] | FactTargets[StoreID] | 1:* | Single |
| 9 | DimRegion[RegionID] | FactTargets[RegionID] | 1:* | Single |

## Why no FactSales ↔ FactTargets link?

Both fact tables connect through shared dimensions (Date, Store, Region). A single Region or Store slicer filters actual sales and targets simultaneously and consistently. A direct relationship between the two facts would create ambiguity and unpredictable filter behavior.

## DimDate dual relationship

- `DimDate[Date]` → `FactSales[OrderDate]` for daily/monthly sales analysis
- `DimDate[YearMonth]` → `FactTargets[TargetMonth]` for target comparisons

Power BI supports multiple relationships from one table to different columns on different fact tables.

## Hidden / unused columns (optional)

Consider hiding from report view:
- `FactSales[ReturnFlag]` (redundant with OrderStatus)
- `DimProduct[StandardCost]` (cost is in FactSales)
- Foreign key columns after relationships are established
