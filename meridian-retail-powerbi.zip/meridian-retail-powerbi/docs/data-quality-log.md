# Data Quality Log — Meridian Retail Power BI Project

Generated: 2026-09-27 14:08 UTC

## FactSales Cleaning Decisions

| Issue | Decision | Count / Notes |
|-------|----------|---------------|
| Raw row count | Baseline before cleaning | 7465 |
| Exact duplicate rows | Removed with `drop_duplicates()` | 95 removed |
| Orphan ProductID rows | Excluded from model; logged for review | 15 rows |
| Blank CustomerID | Kept in fact table; excluded from customer-count measures via DISTINCTCOUNT | 10 rows |
| Blank OrderDate | Kept as null; excluded from time-based visuals via Date relationship | 12 rows |
| Blank DiscountPercent | Replaced with 0 | Applied to all blanks |
| Negative Quantity | Kept sign as-is for returns | Matches Returned status |
| PaymentMethod variants | Standardized to 5 official methods + Other | COD/Wallet/EMI/Cheque → Other |
| SalesChannel / OrderStatus | Trimmed and title-cased | Online/Store; Completed/Cancelled/Returned/Pending |

### Orphan Product Order IDs
- ORD001560
- ORD005810
- ORD003419
- ORD002848
- ORD003241
- ORD000685
- ORD004701
- ORD005963
- ORD006988
- ORD003631
- ORD007144
- ORD006640
- ORD005140
- ORD000047
- ORD003390

## DimProduct Cleaning Decisions

- Trimmed and standardized Category/Subcategory to Title Case.
- Blank Category replaced with `Unknown`.
- Blank Brand/Supplier replaced with `Unknown`.

## DimCustomer Cleaning Decisions

- CustomerName trimmed and title-cased.
- CustomerSegment standardized to Consumer / Small Business / Corporate.
- Blank City replaced with `Unknown`.
- `RegionName_Raw` removed (redundant with DimRegion relationship).

## DimStore Cleaning Decisions

- StoreName trimmed and title-cased.
- Blank StoreManager replaced with `Unassigned`.

## Post-Cleaning Row Count

- FactSales cleaned rows: **7355**
- Expected per answer key: **7,370**

## Quick Validation Snapshot

```json
{
  "gross_sales": 206804740.63,
  "discount_amount": 12810331.78,
  "net_sales": 193994408.85,
  "total_cost": 150856006.3,
  "total_profit": 43138402.55,
  "profit_margin_pct": 22.24,
  "total_orders_completed": 6158,
  "returned_orders": 516,
  "return_rate_pct": 7.73,
  "distinct_customers": 742,
  "total_sales_target": 237684600.0,
  "target_achievement_pct": 81.6,
  "order_status_counts": {
    "Completed": 6158,
    "Returned": 516,
    "Cancelled": 378,
    "Pending": 303
  }
}
```
